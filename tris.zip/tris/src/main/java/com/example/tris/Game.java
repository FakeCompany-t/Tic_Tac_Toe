package com.example.tris;

import java.util.Scanner;




public class Game {
    static final int dim = 3;

//valori che possono essere presenti all'interno del campo
    enum val{V, //vuoto
        X,
        O;
    }

    //val[][] board = new val[dim][dim]; //matrice del campo di gioco

    int x,y;//coordinate

    int nmossa;

    val winner;


    boolean checkWin(val[][] board){
        if ((checkRow(board) || checkCol(board) || checkD(board) || checkS(board))){
            System.out.println(winner);
            return true;
        }
        else {
            return false;
        }
    }

    private boolean checkS(val[][] board) {
        if (board[0][0].equals(board[1][1])&&
        board[0][0].equals(board[2][2])&& isEmpty(board,x,y)){
            val winner = board[0][0];
            return true;
        }
        return false;
    }

    private boolean checkD(val[][] board) {
        if (board[0][2].equals(board[1][1])&&
        board[0][2].equals(board[2][0])&& isEmpty(board,x,y)){
            val winner = board[0][2];
            return true;
        }
        return false;
    }

    private boolean checkCol(val[][] board) {
        for (int i = 0; i < dim; i++) {
            if (board[0][i].equals(board[1][i])&&
                    board[0][i].equals(board[2][i])&&
                    isEmpty(board,x,y)){
                val winner = board[0][i];
                return true;
            }
        }
        return false;
    }

    private boolean checkRow(val[][] board) {
        for (int i = 0; i < dim; i++) {
            if (board[i][0].equals(board[i][1])&&
            board[i][0].equals(board[i][2])&&
            isEmpty(board,x,y)){
                val winner = board[i][0];
                return true;
            }
        }
        return false;
    }

    boolean isDraw(val[][] board){
        if(nmossa==8 && !checkWin(board)){
            System.out.println("Pareggio");
            return true;
        }
        else
            return false;
    }

    boolean isEmpty(val[][] board, int x, int y){
        if(board[x][y]==val.V)
            return true;
        else
            return false;
    }

    void stampa(val[][] board){

        for (int i = 0; i < dim; i++) {
            for (int j = 0; j < dim; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }

    }

    void inizialize_board(val[][] matrice){
        for (int i = 0; i < dim; i++) {
            for (int j = 0; j < dim; j++) {
                matrice[i][j] = val.V;
            }
        }
    }

}
