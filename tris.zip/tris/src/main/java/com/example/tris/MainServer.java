package com.example.tris;

import java.io.IOException;

public class MainServer {

    public static void main(String[] args) throws IOException, ClassNotFoundException {

        ServerGame gioco = new ServerGame();

        //gioco.handshaking();
        gioco.messaggi();

    }
}
